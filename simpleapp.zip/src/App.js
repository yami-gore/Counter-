import logo from './logo.svg';
import './App.css';
import { Counter } from './Counter';
function App() {
  return(
    <div id='div'>
    <h1>Welcome to simple app</h1>
    <Counter count="5"/>
    </div>
  );
}

export default App;
