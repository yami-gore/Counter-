import "./Counter.css"
import { useState,useEffect} from "react";
export function Counter(info)
{
    const[allCount,setCount]=useState(info.count);
        useEffect(() => {
            // document.title = `You clicked ${allCount} times`;
            if(allCount > 10)
            {
                setCount(info.count)
                alert("Count is too high!");
            }
          });
    
    return(
        <div>
           <button id="btn" value={allCount}>{allCount}</button> 
           <button id="btn-incre" onClick={() => setCount(Number(allCount)+1)}>+</button>         
        </div>
    )
}

